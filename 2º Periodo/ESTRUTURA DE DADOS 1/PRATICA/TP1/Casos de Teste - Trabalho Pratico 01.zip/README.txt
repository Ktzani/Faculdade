Arquivo zip gerado em: 18/06/2021 17:22:12 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho Prático 01