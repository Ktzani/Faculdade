Arquivo zip gerado em: 06/07/2021 18:38:27 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Aula Prática 5 - Manipulação de Listas Encadeadas