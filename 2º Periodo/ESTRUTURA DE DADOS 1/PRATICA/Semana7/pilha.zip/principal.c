#include "pilha.h"
#include <stdio.h>
#include <string.h>

int main()
{
      Pilha pilha;
      char ch;
      Item item;

      Pilha_Inicia(&pilha);

      while (scanf("%c", &ch)!=EOF)
      {

      //processar cada elemento lido
        item.carac = ch;

        if (ch == '('){
          if(Pilha_Push(&pilha, item)){
            continue;
          }
        }

        else if (ch == ')'){
          if(Pilha_Pop(&pilha, &item)){
            continue;
          }
          else {
            printf("incorreto\n");
            return 0;
          }
          
        } 
      }

      //determinar o resultado
      if (Pilha_EhVazia(&pilha)){
        printf ("correto\n");
      }

      else{

        printf ("incorreto\n");
      }
  
      //Esvazia pilha, liberando a memoria que foi alocada
      Pilha_Esvazia(&pilha);

      return 0;//nao remova
}
