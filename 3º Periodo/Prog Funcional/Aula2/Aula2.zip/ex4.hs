module Vet where

main :: IO () 

vetor :: Float -> Float -> [Float]
vetor x y = vetn

    where
        v = sqrt (x * x + y * y)

        vetn = [x / v, y / v]

main = return ()